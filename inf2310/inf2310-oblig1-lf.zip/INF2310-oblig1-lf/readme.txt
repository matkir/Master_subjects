
Koden som ligger er løsningsforslag til oblig 1 i INF2310 2017.
Filnavnene samsvarer med oppgavenumrene i obligteksten.

Det finnes to versjoner; en i MATLAB og en i Python -
se i tilhørende mapper for løsningsforslagene.

Her ligger det også en .pdf med noen generelle tips rundt programmering.
Dette er tips jeg har opplevd har vært til stor hjelp, og håper de kan lette på programmeringen for deg óg. 

Hvis du finner noen feil ved kodene eller har andre
spørsmål rundt dem, ta gjerne kontakt på krisbhei@ifi.uio.no eller i gruppetimene!
